package com.example.cardgames;

import android.app.Fragment;

public class SecondFragment extends Fragment {
}
